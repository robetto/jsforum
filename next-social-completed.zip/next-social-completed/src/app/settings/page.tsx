const SettingPage = () => {
  return (
    <div className=''>SettingPage</div>
  )
}

export default SettingPage